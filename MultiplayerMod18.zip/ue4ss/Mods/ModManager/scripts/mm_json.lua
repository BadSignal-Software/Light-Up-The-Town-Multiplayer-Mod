-- Small, forgiving JSON decoder (allows // and /* */ comments, trailing commas, a BOM).
-- Objects keep their key order in Json.order[obj].
local M = {}
M.order = setmetatable({}, { __mode = "k" })

local esc = { ['"'] = '"', ['\\'] = '\\', ['/'] = '/', b = '\b', f = '\f', n = '\n', r = '\r', t = '\t' }

local function fail(s, i, msg)
  local line, col = 1, 1
  for j = 1, math.min(i, #s) do
    if s:sub(j, j) == "\n" then line = line + 1; col = 1 else col = col + 1 end
  end
  error(string.format("line %d, column %d: %s", line, col, msg), 0)
end

local function skip(s, i)
  while true do
    local c = s:sub(i, i)
    if c == " " or c == "\t" or c == "\r" or c == "\n" then
      i = i + 1
    elseif s:sub(i, i + 1) == "//" then
      local e = s:find("\n", i, true); i = e and e + 1 or #s + 1
    elseif s:sub(i, i + 1) == "/*" then
      local _, e = s:find("*/", i + 2, true); if not e then fail(s, i, "unterminated comment") end; i = e + 1
    else
      return i
    end
  end
end

local parse

local function parse_string(s, i)
  local out, j = {}, i + 1
  while true do
    local c = s:sub(j, j)
    if c == "" then fail(s, i, "unterminated string") end
    if c == '"' then return table.concat(out), j + 1 end
    if c == "\\" then
      local n = s:sub(j + 1, j + 1)
      if n == "u" then
        local hex = s:match("^%x%x%x%x", j + 2)
        if not hex then fail(s, j, "bad \\u escape") end
        local cp = tonumber(hex, 16)
        j = j + 6
        if cp >= 0xD800 and cp <= 0xDBFF then
          local lo = s:match("^\\u(%x%x%x%x)", j)
          if lo then cp = 0x10000 + (cp - 0xD800) * 0x400 + (tonumber(lo, 16) - 0xDC00); j = j + 6 end
        end
        out[#out + 1] = utf8.char(cp)
      elseif esc[n] then
        out[#out + 1] = esc[n]; j = j + 2
      else
        fail(s, j, "bad escape \\" .. n)
      end
    else
      out[#out + 1] = c; j = j + 1
    end
  end
end

function parse(s, i)
  i = skip(s, i)
  local c = s:sub(i, i)
  if c == "{" then
    local obj, keys = {}, {}
    M.order[obj] = keys
    i = skip(s, i + 1)
    if s:sub(i, i) == "}" then return obj, i + 1 end
    while true do
      i = skip(s, i)
      if s:sub(i, i) ~= '"' then fail(s, i, "expected a quoted key") end
      local k; k, i = parse_string(s, i)
      i = skip(s, i)
      if s:sub(i, i) ~= ":" then fail(s, i, "expected ':' after key \"" .. k .. "\"") end
      local v; v, i = parse(s, i + 1)
      if obj[k] == nil then keys[#keys + 1] = k end
      obj[k] = v
      i = skip(s, i)
      local d = s:sub(i, i)
      if d == "," then
        i = skip(s, i + 1)
        if s:sub(i, i) == "}" then return obj, i + 1 end
      elseif d == "}" then
        return obj, i + 1
      else
        fail(s, i, "expected ',' or '}'")
      end
    end
  elseif c == "[" then
    local arr = {}
    i = skip(s, i + 1)
    if s:sub(i, i) == "]" then return arr, i + 1 end
    while true do
      local v; v, i = parse(s, i)
      arr[#arr + 1] = v
      i = skip(s, i)
      local d = s:sub(i, i)
      if d == "," then
        i = skip(s, i + 1)
        if s:sub(i, i) == "]" then return arr, i + 1 end
      elseif d == "]" then
        return arr, i + 1
      else
        fail(s, i, "expected ',' or ']'")
      end
    end
  elseif c == '"' then
    return parse_string(s, i)
  elseif s:sub(i, i + 3) == "true" then return true, i + 4
  elseif s:sub(i, i + 4) == "false" then return false, i + 5
  elseif s:sub(i, i + 3) == "null" then return nil, i + 4
  else
    local num = s:match("^-?%d+%.?%d*[eE]?[+-]?%d*", i)
    if num and #num > 0 and tonumber(num) then return tonumber(num), i + #num end
    fail(s, i, "unexpected '" .. c .. "'")
  end
end

function M.decode(s)
  if s:sub(1, 3) == "\239\187\191" then s = s:sub(4) end
  local v, i = parse(s, 1)
  i = skip(s, i)
  if i <= #s then fail(s, i, "unexpected text after the JSON value") end
  return v
end

return M

-- In-game UI: a "mods" button on the main menu and the mod browser panel.
-- Everything is built from plain UMG widgets and attached to the main menu's own widget tree,
-- so it is scaled and layered exactly like the rest of the menu.
local M = {}

local C, Log
local S = {
  host = nil, tree = nil, attach = nil, attachKind = nil,
  button = nil, buttonClick = nil, panel = nil,
  open = false, clicks = {}, selected = nil, tex = {},
  refFont = nil, refFontSize = nil, refColor = nil, brush = nil,
}

-- helpers ----------------------------------------------------------------------
local function valid(o)
  if o == nil then return false end
  local ok, v = pcall(function() return o:IsValid() end)
  return ok and v == true
end

-- Pause-menu widgets are created and thrown away by the game all the time, and old ones get garbage
-- collected in bulk (map changes). A Lua reference to one can end up dangling, and touching it can crash
-- the game. So for those we keep only the object's *path* and look the object up fresh each time.
local function objPath(o)
  local ok, n = pcall(function() return o:GetFullName() end)
  if ok and type(n) == "string" then return (n:gsub("^%S+%s+", "")) end
end

local function resolve(path)
  if not path then return nil end
  local ok, o = pcall(StaticFindObject, path)
  if ok and o ~= nil and valid(o) then return o end
  return nil
end

local function entryWidget(e)
  if e.resolve then return e.resolve() end
  if valid(e.w) then return e.w end
  return nil
end

local function try(what, fn, ...)
  local ok, err = pcall(fn, ...)
  if not ok then Log("[" .. what .. "] " .. tostring(err)) end
  return ok, err
end

local function srgb(c)
  c = c / 255
  if c <= 0.04045 then return c / 12.92 end
  return ((c + 0.055) / 1.055) ^ 2.4
end
local function color(hex, a)
  local r, g, b = hex:match("#?(%x%x)(%x%x)(%x%x)")
  return { R = srgb(tonumber(r, 16)), G = srgb(tonumber(g, 16)), B = srgb(tonumber(b, 16)), A = a or 1 }
end
local function slate(hex, a) return { SpecifiedColor = color(hex, a), ColorUseRule = 0 } end
local function lighten(c, k) return { R = c.R + (1 - c.R) * k, G = c.G + (1 - c.G) * k, B = c.B + (1 - c.B) * k, A = c.A } end
local function P(name) return C.PAL[name] end

local function new(className)
  local cls = StaticFindObject("/Script/UMG." .. className)
  return StaticConstructObject(cls, S.tree)
end

local HFILL, HLEFT, HCENTER, HRIGHT = 0, 1, 2, 3
local VFILL, VTOP, VCENTER, VBOTTOM = 0, 1, 2, 3

-- add child to a panel and tweak its slot
local function add(parent, child, o)
  local sl = parent:AddChild(child)
  if o and sl then
    if o.pad then try("pad", function() sl:SetPadding({ Left = o.pad[1], Top = o.pad[2], Right = o.pad[3], Bottom = o.pad[4] }) end) end
    if o.fill then try("fill", function() sl:SetSize({ Value = o.fill, SizeRule = 1 }) end) end
    if o.h then try("h", function() sl:SetHorizontalAlignment(o.h) end) end
    if o.v then try("v", function() sl:SetVerticalAlignment(o.v) end) end
  end
  return sl
end

local function font(t, size)
  try("font", function()
    local f = t.Font
    if S.refFont then
      if S.refFont.obj then f.FontObject = S.refFont.obj end
      if S.refFont.face then f.TypefaceFontName = S.refFont.face end
    end
    f.Size = size
  end)
end

local function text(str, size, hex, o)
  o = o or {}
  local t = new("TextBlock")
  font(t, size)
  try("text", function() t:SetText(FText(str or "")) end)
  try("textcolor", function() t:SetColorAndOpacity(slate(hex or P("text"))) end)
  if o.wrap then try("wrap", function() t:SetAutoWrapText(true) end) end
  if o.center then try("just", function() t:SetJustification(1) end) end
  return t
end

-- a rounded box. kind = "pill" (half-height radius) or a pixel radius
local function roundBorder(kind)
  local b = new("Border")
  try("roundbox", function()
    local bg = b.Background
    bg.DrawAs = 4 -- RoundedBox
    if kind == "pill" then
      bg.OutlineSettings.RoundingType = 1
    else
      bg.OutlineSettings.RoundingType = 0
      bg.OutlineSettings.CornerRadii = { X = kind, Y = kind, Z = kind, W = kind }
    end
    bg.TintColor = slate("#ffffff")
  end)
  return b
end

-- White-outlined pastel box like the game's buttons: outer white rounded box, inner coloured one.
-- Returns outer (add this), inner (set content / colour on this).
local function framed(kind, fillHex, alpha, outlineHex, outlinePx)
  local outer = roundBorder(kind)
  local inner = roundBorder(kind == "pill" and "pill" or math.max(kind - (outlinePx or 5), 4))
  try("outer", function() outer:SetBrushColor(color(outlineHex or "#ffffff")) end)
  try("innercol", function() inner:SetBrushColor(color(fillHex, alpha)) end)
  local px = outlinePx or 5
  try("outerpad", function() outer:SetPadding({ Left = px, Top = px, Right = px, Bottom = px }) end)
  try("outerchild", function() outer:SetContent(inner) end)
  return outer, inner
end

local function sized(child, w, h)
  local sb = new("SizeBox")
  if w then try("w", function() sb:SetWidthOverride(w) end) end
  if h then try("h", function() sb:SetHeightOverride(h) end) end
  try("sbc", function() sb:SetContent(child) end)
  return sb
end

-- Clickables: handled by one global left-click key bind + IsHovered(), because Lua can't
-- bind UMG button delegates reliably.
local function clickable(inner, fn, baseColor, group)
  local base = baseColor
  local entry = { w = inner, fn = fn, base = base, hov = lighten(base, 0.22), hovered = false, group = group or "panel" }
  S.clicks[#S.clicks + 1] = entry
  return entry
end

local function setColor(entry, hovered)
  if valid(entry.w) and not entry.notint then
    try("hover", function() entry.w:SetBrushColor(hovered and entry.hov or entry.base) end)
  end
end

local function isActive(e)
  if S.open and valid(S.panel) then return e.group == "panel" or e.group == "detail" end
  return e.group == "menu"
end

-- Fade the button out after a few idle seconds and bring it back when the mouse moves,
-- like the game's own menu buttons.
local function mousePos()
  local ok, p = pcall(function()
    local lib = StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary")
    local v = lib:GetMousePositionOnViewport((S.ctxMain and S.ctxMain.host) or S.host)
    return { x = v.X, y = v.Y }
  end)
  if ok and p and type(p.x) == "number" and type(p.y) == "number" then return p end
end

local function fadeTick()
  local secs = C.IDLE_FADE_SECONDS
  if not secs or secs <= 0 or S.noFade or not valid(S.button) then return end
  local now = os.time()
  S.lastMove = S.lastMove or now
  if S.open then S.lastMove = now; S.lastPos = nil; return end
  local p = mousePos()
  if not p then
    S.fadeFails = (S.fadeFails or 0) + 1
    if S.fadeFails > 20 then
      S.noFade = true
      Log("Couldn't read the mouse position; the mods button won't fade.")
      try("op", function() S.button:SetRenderOpacity(1); S.button:SetVisibility(0) end)
    end
    return
  end
  if not S.lastPos or math.abs(p.x - S.lastPos.x) + math.abs(p.y - S.lastPos.y) > 0.5 then S.lastMove = now end
  S.lastPos = p
  local target = (now - S.lastMove >= secs) and 0 or 1
  local a = S.alpha or 1
  if a < target then a = math.min(1, a + 0.2) elseif a > target then a = math.max(0, a - 0.05) end
  if a ~= S.alpha then
    S.alpha = a
    try("opacity", function() S.button:SetRenderOpacity(a) end)
    local hidden = (a < 0.05 and target == 0)
    if hidden ~= S.fadeHidden then
      S.fadeHidden = hidden
      try("vis", function() S.button:SetVisibility(hidden and 3 or 0) end)
    end
  end
end
M.fadeTick = fadeTick

function M.hoverTick()
  fadeTick()
  if #S.clicks == 0 then return end
  for _, e in ipairs(S.clicks) do
    if isActive(e) and not (e.owner == "pause" and not S.pauseShown) then
      local w = entryWidget(e)
      if w then
        local ok, h = pcall(function() return w:IsHovered() end)
        h = ok and h == true
        if h ~= e.hovered then e.hovered = h; setColor(e, h) end
      end
    end
  end
end

local lastClick = -10
function M.click()
  local now = os.clock()
  if now - lastClick < 0.18 then return end
  for i = #S.clicks, 1, -1 do
    local e = S.clicks[i]
    local w = isActive(e) and entryWidget(e) or nil
    if w then
      local ok, h = pcall(function() return w:IsHovered() end)
      if ok and h == true then
        lastClick = now
        try("click", e.fn)
        return
      end
    end
  end
end

local function dropClicks(group)
  local keep = {}
  for _, e in ipairs(S.clicks) do if e.group ~= group then keep[#keep + 1] = e end end
  S.clicks = keep
end

local function dropOwner(owner)
  local keep = {}
  for _, e in ipairs(S.clicks) do if e.owner ~= owner then keep[#keep + 1] = e end end
  S.clicks = keep
end

local function useCtx(c)
  if c and valid(c.host) then S.host, S.tree, S.attach, S.attachKind = c.host, c.tree, c.attach, c.kind end
end

-- textures -------------------------------------------------------------------
local function loadTexture(path)
  if not path then return nil end
  local t = S.tex[path]
  if t and valid(t) then return t end
  local ok, tex = pcall(function()
    local lib = StaticFindObject("/Script/Engine.Default__KismetRenderingLibrary")
    return lib:ImportFileAsTexture2D(S.host, path)
  end)
  if ok and tex and valid(tex) then S.tex[path] = tex; return tex end
  Log("Couldn't load image " .. tostring(path) .. (ok and "" or (": " .. tostring(tex))))
  return nil
end

local function fit(w, h, maxW, maxH)
  if not w or not h or w == 0 or h == 0 then w, h = 16, 9 end
  local k = math.min(maxW / w, maxH / h)
  return math.floor(w * k), math.floor(h * k)
end

local function imageWidget(path, w, h)
  local img = new("Image")
  local tex = loadTexture(path)
  if tex then try("brush", function() img:SetBrushFromTexture(tex, false) end) end
  return sized(img, w, h), img, tex ~= nil
end

-- panel ----------------------------------------------------------------------
local function clearBox(box) try("clear", function() box:ClearChildren() end) end

local function pillRow(items, hex, textHex)
  local wrap = new("WrapBox")
  try("inner", function() wrap:SetInnerSlotPadding({ X = 10, Y = 10 }) end)
  for _, it in ipairs(items) do
    local outer, inner = framed("pill", hex, 1, "#ffffff", 3)
    try("padd", function() inner:SetPadding({ Left = 18, Top = 4, Right = 18, Bottom = 6 }) end)
    try("c", function() inner:SetContent(text(it, 22, textHex)) end)
    add(wrap, outer)
  end
  return wrap
end

local function heading(str) return text(str, 34, P("flame")) end

local function showMod(mod)
  local box = S.detail
  if not valid(box) then return end
  clearBox(box)
  dropClicks("detail")
  local gap = { 0, 0, 0, 14 }

  add(box, text(mod.name, 64, P("text")), { pad = { 0, 0, 0, 4 } })
  local meta = {}
  if mod.version then meta[#meta + 1] = "v" .. mod.version end
  if mod.author then meta[#meta + 1] = "by " .. mod.author end
  if mod.game_version then meta[#meta + 1] = "game " .. mod.game_version end
  meta[#meta + 1] = mod.enabled and "enabled" or "disabled"
  add(box, text(table.concat(meta, "   -   "), 26, P("subtle")), { pad = { 0, 0, 0, 14 } })

  if not mod.is_self then
    local o, i = framed("pill", mod.enabled and P("salmon") or P("sage"), 1, "#ffffff", 4)
    try("tg", function() i:SetPadding({ Left = 30, Top = 4, Right = 30, Bottom = 8 }) end)
    try("tgc", function() i:SetContent(text(mod.enabled and "turn off" or "turn on", 28, P("dark"))) end)
    add(box, o, { h = HLEFT, pad = { 0, 0, 0, 12 } })
    clickable(i, function()
      if M.onToggle then M.onToggle(mod) end
      showMod(mod)
    end, color(mod.enabled and P("salmon") or P("sage")), "detail")
  end
  if mod.toggle_error then
    add(box, text("couldn't change this: " .. tostring(mod.toggle_error), 24, P("salmon"), { wrap = true }), { pad = { 0, 0, 0, 10 } })
  elseif mod.changed then
    add(box, text("restart the game to apply this change", 24, P("flame")), { pad = { 0, 0, 0, 10 } })
  end
  add(box, sized(text(" ", 8, P("subtle")), nil, 8))

  if mod.icon then
    local sb = imageWidget(mod.icon.path, 128, 128)
    add(box, sb, { pad = { 0, 0, 0, 18 }, h = HLEFT })
  end

  if #mod.problems > 0 then
    for _, p in ipairs(mod.problems) do
      add(box, text(p, 26, P("salmon"), { wrap = true }), { pad = gap })
    end
  end
  if #mod.tags > 0 then add(box, pillRow(mod.tags, P("sage"), P("dark")), { pad = { 0, 0, 0, 18 } }) end
  if mod.description then add(box, text(mod.description, 30, P("text"), { wrap = true }), { pad = { 0, 0, 0, 14 } }) end
  if mod.long_description then add(box, text(mod.long_description, 26, P("subtle"), { wrap = true }), { pad = { 0, 0, 0, 22 } }) end

  local info = {}
  if mod.website then info[#info + 1] = { "website", mod.website } end
  if #mod.dependencies > 0 then info[#info + 1] = { "needs", table.concat(mod.dependencies, ", ") } end
  info[#info + 1] = { "folder", mod.folder }
  if mod.source then info[#info + 1] = { "info file", mod.source } end
  for _, e in ipairs(mod.extras) do info[#info + 1] = { e.key, e.value } end
  add(box, heading("info"), { pad = { 0, 4, 0, 8 } })
  for _, row in ipairs(info) do
    local h = new("HorizontalBox")
    add(h, sized(text(row[1], 24, P("subtle")), 200, nil), { v = VTOP })
    add(h, text(row[2], 24, P("text"), { wrap = true }), { fill = 1 })
    add(box, h, { pad = { 0, 0, 0, 8 } })
  end

  if #mod.images > 0 then
    add(box, heading("pictures"), { pad = { 0, 22, 0, 10 } })
    local previewHolder = new("VerticalBox")
    local previewCaption = text("", 24, P("subtle"), { wrap = true })
    local thumbs = new("WrapBox")
    try("tp", function() thumbs:SetInnerSlotPadding({ X = 14, Y = 14 }) end)

    local function selectImage(img)
      clearBox(previewHolder)
      if img.path then
        local pw, ph = fit(img.w, img.h, 880, 500)
        local sb, _, ok = imageWidget(img.path, pw, ph)
        if ok then add(previewHolder, sb, { h = HLEFT, pad = { 0, 0, 0, 10 } })
        else add(previewHolder, text("(couldn't load " .. img.file .. ")", 24, P("salmon")), { pad = { 0, 0, 0, 10 } }) end
      else
        add(previewHolder, text("image not found in the images folder: " .. img.file, 24, P("salmon"), { wrap = true }), { pad = { 0, 0, 0, 10 } })
      end
      local cap = img.title
      if img.caption then cap = cap .. "\n" .. img.caption end
      if img.w and img.h then cap = cap .. "\n" .. img.w .. " x " .. img.h end
      try("cap", function() previewCaption:SetText(FText(cap)) end)
    end

    for _, img in ipairs(mod.images) do
      local outer, inner = framed(18, P("purple"), 1, "#ffffff", 4)
      try("tpad", function() inner:SetPadding({ Left = 4, Top = 4, Right = 4, Bottom = 4 }) end)
      local tw, th = fit(img.w, img.h, 190, 110)
      local sb = imageWidget(img.path, tw, th)
      try("tc", function() inner:SetContent(sb) end)
      add(thumbs, outer)
      clickable(inner, function() selectImage(img) end, color(P("purple")), "detail")
    end
    selectImage(mod.images[1])
    add(box, previewHolder)
    add(box, previewCaption, { pad = { 0, 0, 0, 14 } })
    if #mod.images > 1 then add(box, thumbs, { pad = { 0, 0, 0, 10 } }) end
  end
  add(box, sized(text(" ", 20, P("subtle")), nil, 40))
  try("scrolltop", function() S.detailScroll:ScrollToStart() end)
end

local function highlight(index)
  S.selected = index
  for i, it in ipairs(S.items or {}) do
    if valid(it.outer) then
      try("hl", function() it.outer:SetBrushColor(color(i == index and P("flame") or "#ffffff")) end)
    end
  end
end

local function selectMod(index)
  local mod = S.mods and S.mods[index]
  if not mod then return end
  highlight(index)
  showMod(mod)
end

local pastel = { "purple", "olive", "salmon", "sage", "sand", "lavender" }

local function buildPanel(mods)
  S.mods = mods
  S.items = {}
  dropClicks("panel")

  local dim = new("Border")
  try("dim", function() dim:SetBrushColor(color(P("dim"), 0.78)) end)
  try("dimv", function() dim:SetVisibility(0) end)

  local cardOuter, card = framed(36, P("card"), 0.97, "#ffffff", 6)
  try("cardpad", function() card:SetPadding({ Left = 44, Top = 30, Right = 44, Bottom = 36 }) end)
  local root = new("VerticalBox")

  -- header
  local head = new("HorizontalBox")
  add(head, text(C.BUTTON_LABEL, 76, P("text")), { fill = 1, v = VCENTER })
  local ro, ri = framed("pill", P("sage"), 1, "#ffffff", 5)
  try("rp", function() ri:SetPadding({ Left = 40, Top = 8, Right = 40, Bottom = 12 }) end)
  try("rc", function() ri:SetContent(text("reload", 36, P("dark"))) end)
  add(head, ro, { v = VCENTER, pad = { 0, 0, 20, 0 } })
  clickable(ri, function()
    local cur = S.mods and S.mods[S.selected or 0]
    S.keepFolder = cur and cur.folder
    S.tex = {}
    local fresh = M.onReload and M.onReload()
    if fresh then M.open(fresh) end
  end, color(P("sage")), "panel")
  local bo, bi = framed("pill", P("salmon"), 1, "#ffffff", 5)
  try("bp", function() bi:SetPadding({ Left = 40, Top = 8, Right = 40, Bottom = 12 }) end)
  try("bc", function() bi:SetContent(text("back", 36, P("dark"))) end)
  add(head, bo, { v = VCENTER })
  clickable(bi, function() M.close() end, color(P("salmon")), "panel")
  add(root, head, { pad = { 0, 0, 0, 20 } })

  -- body
  local body = new("HorizontalBox")
  local list = new("VerticalBox")
  local listScroll = new("ScrollBox")
  try("lsb", function() listScroll:SetScrollBarVisibility(1) end)
  try("lsc", function() listScroll:SetOrientation(0) end)
  if #mods == 0 then
    add(list, text("no mods with a modmanager.json or modmanager.txt were found in the Mods folder.", 28, P("subtle"), { wrap = true }), { pad = { 8, 8, 8, 8 } })
  end
  for i, mod in ipairs(mods) do
    local outer, inner = framed(30, P(pastel[(i - 1) % #pastel + 1]), 1, "#ffffff", 5)
    try("ip", function() inner:SetPadding({ Left = 26, Top = 14, Right = 26, Bottom = 16 }) end)
    local col = new("VerticalBox")
    add(col, text(mod.name, 34, P("dark"), { wrap = true }))
    local sub = mod.version and ("v" .. mod.version) or ""
    if mod.author then sub = sub .. (sub ~= "" and "  -  " or "") .. mod.author end
    if #mod.problems > 0 then sub = sub .. (sub ~= "" and "  -  " or "") .. "!" end
    if sub ~= "" then add(col, text(sub, 22, P("dark"), { wrap = true })) end
    try("ic", function() inner:SetContent(col) end)
    add(list, outer, { pad = { 6, 0, 14, 16 } })
    S.items[i] = { outer = outer, inner = inner }
    clickable(inner, function() selectMod(i) end, color(P(pastel[(i - 1) % #pastel + 1])), "panel")
  end
  try("ls", function() listScroll:AddChild(list) end)
  add(body, sized(listScroll, 460, nil), { pad = { 0, 0, 24, 0 } })

  local detail = new("VerticalBox")
  local detailScroll = new("ScrollBox")
  try("dsb", function() detailScroll:SetScrollBarVisibility(1) end)
  try("dsc", function() detailScroll:AddChild(detail) end)
  add(body, detailScroll, { fill = 1 })
  S.detail, S.detailScroll, S.listScroll = detail, detailScroll, listScroll
  add(root, body, { fill = 1 })

  try("cr", function() card:SetContent(root) end)
  local cardSize = sized(cardOuter, 1560, 900)
  try("dimc", function() dim:SetContent(cardSize) end)
  try("dimh", function() dim:SetHorizontalAlignment(HCENTER); dim:SetVerticalAlignment(VCENTER) end)

  if #mods > 0 then
    local pick = 1
    for i, m in ipairs(mods) do if S.keepFolder and m.folder == S.keepFolder then pick = i end end
    S.keepFolder = nil
    selectMod(pick)
  end
  return dim
end

-- attaching to the menu -----------------------------------------------------------
local function attachFull(widget)
  local sl = S.attach:AddChild(widget)
  if S.attachKind == "canvas" then
    try("anch", function() sl:SetAnchors({ Minimum = { X = 0, Y = 0 }, Maximum = { X = 1, Y = 1 } }) end)
    try("off", function() sl:SetOffsets({ Left = 0, Top = 0, Right = 0, Bottom = 0 }) end)
    try("z", function() sl:SetZOrder(5000) end)
  else
    try("ha", function() sl:SetHorizontalAlignment(HFILL); sl:SetVerticalAlignment(VFILL) end)
  end
  return sl
end

local function attachCorner(widget, geom)
  local sl = S.attach:AddChild(widget)
  local m = C.BUTTON_MARGIN
  if S.attachKind == "canvas" then
    try("anch", function() sl:SetAnchors({ Minimum = { X = 0, Y = 1 }, Maximum = { X = 0, Y = 1 } }) end)
    try("al", function() sl:SetAlignment({ X = 0, Y = 1 }) end)
    try("pos", function() sl:SetPosition({ X = m.left, Y = -m.bottom }) end)
    if geom and type(geom.w) == "number" and geom.w > 0 then
      try("size", function() sl:SetSize({ X = geom.w, Y = geom.h }) end)
      try("auto", function() sl:SetAutoSize(geom.auto == true) end)
    else
      try("auto", function() sl:SetAutoSize(true) end)
    end
    try("z", function() sl:SetZOrder(4000) end)
  else
    try("ha", function() sl:SetHorizontalAlignment(HLEFT); sl:SetVerticalAlignment(VBOTTOM) end)
    try("pad", function() sl:SetPadding({ Left = m.left, Top = 0, Right = 0, Bottom = m.bottom }) end)
  end
  return sl
end

function M.open(mods)
  if not valid(S.host) or not S.attach then return end
  if valid(S.panel) then try("rm", function() S.panel:RemoveFromParent() end) end
  S.panel = buildPanel(mods)
  attachFull(S.panel)
  S.open = true
end

function M.close()
  if valid(S.panel) then try("rm", function() S.panel:RemoveFromParent() end) end
  S.panel = nil
  S.open = false
  dropClicks("panel"); dropClicks("detail")
end

function M.isOpen() return S.open and valid(S.panel) end

function M.scroll(delta)
  if not M.isOpen() then return end
  try("scroll", function()
    local sc = S.detailScroll
    sc:SetScrollOffset(math.max(0, sc:GetScrollOffset() + delta))
  end)
end

-- Look the menu up -------------------------------------------------------------------
local function lowerText(tb)
  local ok, s = pcall(function() return tb:GetText():ToString() end)
  if ok and type(s) == "string" then return (s:gsub("^%s+", ""):gsub("%s+$", "")):lower() end
end

local function isA(o, path)
  local ok, r = pcall(function() return o:IsA(StaticFindObject(path)) end)
  return ok and r == true
end

local function className(w)
  local ok, n = pcall(function() return w:GetClass():GetFName():ToString() end)
  return ok and n or "?"
end

local function rootKind(host)
  local ok, root = pcall(function() return host.WidgetTree.RootWidget end)
  if not ok or not valid(root) then return nil end
  if isA(root, "/Script/UMG.CanvasPanel") then return root, "canvas" end
  if isA(root, "/Script/UMG.Overlay") then return root, "overlay" end
end

-- From a text block, climb to (its button widget, the menu widget, the menu's root panel, panel kind).
-- The menu widget is the first user widget up the chain whose root is a Canvas/Overlay.
local function menuOf(tb)
  local o, firstUser = tb, nil
  for _ = 1, 10 do
    local ok, outer = pcall(function() return o:GetOuter() end)
    if not ok or not valid(outer) then return nil end
    o = outer
    if isA(o, "/Script/UMG.UserWidget") then
      local root, kind = rootKind(o)
      if root then return firstUser, o, root, kind end
      firstUser = firstUser or o
    end
  end
end

local function hostOk(host, cls)
  cls = cls or C.MENU_HOST_CLASS
  if cls and className(host) ~= cls then return false end
  local ok, vis = pcall(function() return host:GetVisibility() end)
  return (not ok) or vis == 0 or vis == 3 or vis == 4
end

local function harvestFont(tb)
  S.refFont, S.refFontSize = nil, nil
  try("refFont", function()
    local f = tb.Font
    S.refFont = { obj = f.FontObject, face = f.TypefaceFontName }
    S.refFontSize = f.Size
  end)
end

local function collectTexts(w, out, depth)
  if depth > 14 or not valid(w) then return out end
  if lowerText(w) ~= nil then out[#out + 1] = w end
  local oku, tree = pcall(function() return w.WidgetTree end)
  if oku and valid(tree) then collectTexts(tree.RootWidget, out, depth + 1) end
  local okc, n = pcall(function() return w:GetChildrenCount() end)
  if okc and type(n) == "number" then
    for i = 0, n - 1 do
      local okx, ch = pcall(function() return w:GetChildAt(i) end)
      if okx then collectTexts(ch, out, depth + 1) end
    end
  end
  return out
end

local function setLabel(btn)
  if not valid(btn) then return end
  for _, t in ipairs(collectTexts(btn, {}, 0)) do
    try("label", function() t:SetText(FText(C.BUTTON_LABEL)) end)
  end
end

-- Make a real copy of the game's own menu button (same Blueprint class) so it looks identical.
local function createGameButton(host, ref)
  if not valid(ref) then return nil end
  local ok, nb = pcall(function()
    local lib = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
    local pc = FindFirstOf("PlayerController")
    return lib:Create(host, ref:GetClass(), pc)
  end)
  if not ok or not valid(nb) then
    Log("Couldn't create a copy of the game's button: " .. tostring(nb))
    return nil
  end
  setLabel(nb)
  if C.BUTTON_TINT_HEX then try("tint", function() nb:SetColorAndOpacity(color(C.BUTTON_TINT_HEX)) end) end
  return nb
end

local function buildPillButton()
  local w, h = C.BUTTON_SIZE.w, C.BUTTON_SIZE.h
  local fontSize = type(S.refFontSize) == "number" and math.floor(S.refFontSize) or 44
  local hex = C.BUTTON_TINT_HEX or P("lavender")
  local outer, inner = framed("pill", hex, 1, "#ffffff", 5)
  try("bha", function() inner:SetHorizontalAlignment(HCENTER); inner:SetVerticalAlignment(VCENTER) end)
  try("bcontent", function() inner:SetContent(text(C.BUTTON_LABEL, fontSize, P("dark"))) end)
  return sized(outer, w, h), inner, color(hex)
end

local warned = 0
-- Called by the poll loop. Makes sure the mods button exists on the current main menu.
function M.ensureButton()
  if S.button then
    if valid(S.button) and S.ctxMain and valid(S.ctxMain.host) and hostOk(S.ctxMain.host) then return true end
    S.button, S.panel, S.open = nil, nil, false
    dropOwner("main"); dropClicks("panel"); dropClicks("detail")
  end

  local texts = {}
  for _, cn in ipairs({ "CommonTextBlock", "TextBlock" }) do
    local l = FindAllOf(cn)
    if l then for _, t in ipairs(l) do texts[#texts + 1] = t end end
  end
  local markers = {}
  for _, m in ipairs(C.MENU_MARKER_TEXTS) do markers[m:lower()] = true end

  local found
  for _, tb in ipairs(texts) do
    if valid(tb) then
      local s = lowerText(tb)
      if s and markers[s] then
        local ref, host, root, kind = menuOf(tb)
        if host and hostOk(host) then found = { tb = tb, ref = ref, host = host, root = root, kind = kind }; break end
      end
    end
  end
  if not found then
    if warned < 3 then
      warned = warned + 1
      Log("Main menu not found yet (looked at " .. #texts .. " text blocks).")
    end
    return false
  end

  -- prefer the "settings" button as the one to copy
  local styleName = C.STYLE_SOURCE_TEXT:lower()
  local ref = found.ref
  for _, tb in ipairs(texts) do
    if valid(tb) and lowerText(tb) == styleName then
      local r, h2 = menuOf(tb)
      if h2 and h2 == found.host and valid(r) then ref = r; break end
    end
  end

  S.host, S.tree, S.attach, S.attachKind = found.host, found.host.WidgetTree, found.root, found.kind
  S.ctxMain = { host = found.host, tree = found.host.WidgetTree, attach = found.root, kind = found.kind }
  harvestFont(found.tb)

  -- geometry of the button we copy (size), so the copy is the same size
  local geom
  if valid(ref) then
    pcall(function()
      local rs = ref.Slot
      local sz = rs:GetSize()
      geom = { w = sz.X, h = sz.Y, auto = rs:GetAutoSize() }
    end)
  end

  local widget = createGameButton(found.host, ref)
  local target, base
  if widget then
    target, base = widget, { R = 1, G = 1, B = 1, A = 1 }
    Log("Created the mods button from the game's own button class (" .. className(ref) .. ").")
  else
    widget, target, base = buildPillButton()
    geom = nil
  end
  attachCorner(widget, geom)
  S.button = widget
  S.alpha, S.fadeHidden, S.lastMove, S.lastPos, S.fadeFails, S.noFade = 1, false, os.time(), nil, 0, false
  local entry = clickable(target, function() useCtx(S.ctxMain); if M.onMods then M.onMods() end end, base, "menu")
  entry.owner = "main"
  if target == widget then entry.notint = true end
  -- the game's button may reset its label when it is first constructed; set it again shortly after
  if ExecuteWithDelay then
    ExecuteWithDelay(300, function() ExecuteInGameThread(function() setLabel(S.button) end) end)
    ExecuteWithDelay(1500, function() ExecuteInGameThread(function() setLabel(S.button) end) end)
  end
  Log("Added the mods button to the main menu (" .. found.kind .. ", host " .. className(found.host) .. ").")
  return true
end

function M.hasMenu()
  local pc = M.pauseCtx and M.pauseCtx()
  if pc then useCtx(pc); return true end
  if valid(S.button) and S.ctxMain and valid(S.ctxMain.host) then useCtx(S.ctxMain); return true end
  return false
end

-- Pause menu: a "mods" button right under "options" (a copy of the game's own button class) ---------
local function readSlot(w)
  local p = {}
  pcall(function()
    local sl = w.Slot
    local pd = sl.Padding
    p.pad = { Left = pd.Left, Top = pd.Top, Right = pd.Right, Bottom = pd.Bottom }
    p.h = sl.HorizontalAlignment
    p.v = sl.VerticalAlignment
    local sz = sl.Size
    p.size = { Value = sz.Value, SizeRule = sz.SizeRule }
  end)
  return p
end

local function applySlot(w, p)
  local ok, sl = pcall(function() return w.Slot end)
  if not ok or not sl then return end
  if p.pad then try("pad", function() sl:SetPadding(p.pad) end) end
  if type(p.h) == "number" then try("h", function() sl:SetHorizontalAlignment(p.h) end) end
  if type(p.v) == "number" then try("v", function() sl:SetVerticalAlignment(p.v) end) end
  if p.size and type(p.size.Value) == "number" then try("size", function() sl:SetSize(p.size) end) end
end

local function insertAfter(container, after, mine)
  local idx
  local okIdx = pcall(function() idx = container:GetChildIndex(after) end)
  if not okIdx or type(idx) ~= "number" or idx < 0 then
    Log("Couldn't find the options button inside its container.")
    return false
  end
  local props = readSlot(after)
  local tail = {}
  pcall(function()
    local n = container:GetChildrenCount()
    for i = idx + 1, n - 1 do
      local w = container:GetChildAt(i)
      tail[#tail + 1] = { w = w, p = readSlot(w) }
    end
  end)
  -- 1) direct insert, if the engine lets us
  local placed = false
  pcall(function()
    container:InsertChildAt(idx + 1, mine)
    placed = (container:GetChildIndex(mine) == idx + 1)
  end)
  if placed then applySlot(mine, props); return true end
  pcall(function() container:RemoveChild(mine) end)
  -- 2) append, then move everything that was below "options" underneath it
  pcall(function() container:AddChild(mine) end)
  applySlot(mine, props)
  for _, t in ipairs(tail) do
    pcall(function() container:RemoveChild(t.w) end)
    pcall(function() container:AddChild(t.w) end)
    applySlot(t.w, t.p)
  end
  local ok2, now = pcall(function() return container:GetChildIndex(mine) end)
  return ok2 and now == idx + 1
end

-- find the panel that directly contains `target`, by walking down from `w` (no .Parent reads)
local function sameObj(a, b)
  local ok, r = pcall(function() return a:GetFullName() == b:GetFullName() end)
  return ok and r == true
end

local function findContainer(w, target, depth)
  if depth > 14 or not valid(w) then return nil end
  local okc, n = pcall(function() return w:GetChildrenCount() end)
  if okc and type(n) == "number" then
    for i = 0, n - 1 do
      local okx, ch = pcall(function() return w:GetChildAt(i) end)
      if okx and valid(ch) then
        if sameObj(ch, target) then return w end
        local r = findContainer(ch, target, depth + 1)
        if r then return r end
      end
    end
  end
  local oku, tree = pcall(function() return w.WidgetTree end)
  if oku and valid(tree) then return findContainer(tree.RootWidget, target, depth + 1) end
  return nil
end

local pauseTried = {}
local pauseTries = {}

-- is the pause menu currently open? (activatable widgets report IsActivated; otherwise use visibility)
local function pauseIsOpen(host)
  if not valid(host) or not hostOk(host, C.PAUSE_HOST_CLASS) then return false end
  local ok, a = pcall(function() return host:IsActivated() end)
  if ok and type(a) == "boolean" then return a end
  return true
end

local reopenLogs = 0

local seenKeys = {}
local function once(key, msg)
  if not seenKeys[key] then seenKeys[key] = true; Log(msg) end
end

local pauseWarned = false
local mirrorLogs = 0

-- Copy the options button's visibility/opacity onto our button every tick. The game animates
-- its buttons in and out each time the menu opens; ours isn't part of that, so it must follow.
function M.pauseCtx()
  local host = resolve(S.pauseHostPath)
  if not host or not resolve(S.pauseBtnPath) then return nil end
  local root, kind = rootKind(host)
  if not root then return nil end
  local okt, tree = pcall(function() return host.WidgetTree end)
  return { host = host, tree = okt and tree or nil, attach = root, kind = kind }
end

local function mirrorPause()
  local ref, mine = resolve(S.pauseRefPath), resolve(S.pauseBtnPath)
  if not (ref and mine) then return false end
  local ok, vis, op = pcall(function() return ref:GetVisibility(), ref:GetRenderOpacity() end)
  if not ok or type(vis) ~= "number" then return true end
  if type(op) ~= "number" then op = 1 end
  if vis ~= S.pauseVis or math.abs(op - (S.pauseOp or -1)) > 0.02 then
    if mirrorLogs < 40 then
      mirrorLogs = mirrorLogs + 1
      Log("pause: options button vis=" .. tostring(vis) .. " opacity=" .. string.format("%.2f", op))
    end
    S.pauseVis, S.pauseOp = vis, op
    pcall(function() mine:SetRenderOpacity(op) end)
    pcall(function() mine:SetVisibility(vis) end)
  end
  S.pauseShown = (vis == 0 or vis == 3 or vis == 4) and op > 0.05
  return true
end

local watchLast, watchLines = nil, 0
-- Diagnostics: log every change in what the game has for the pause menu (instances, visibility).
local function pauseWatch()
  if not C.PAUSE_WATCH or watchLines >= 150 then return end
  local parts = {}
  local hosts = FindAllOf(C.PAUSE_HOST_CLASS)
  if hosts then
    for _, h in ipairs(hosts) do
      local ok, d = pcall(function()
        if not valid(h) then return "invalid" end
        local nm = h:GetFullName():match("([%w_]+)$") or "?"
        local vis = h:GetVisibility()
        local _, inv = pcall(function() return h:IsInViewport() end)
        return nm:sub(-6) .. " vis=" .. tostring(vis) .. " inVP=" .. tostring(inv)
      end)
      parts[#parts + 1] = ok and d or ("err:" .. tostring(d))
    end
  end
  local sig = #parts .. " host(s): " .. table.concat(parts, " | ")
    .. " | button=" .. tostring(S.pauseBtnPath ~= nil)
  if sig ~= watchLast then
    watchLast = sig
    watchLines = watchLines + 1
    Log("pause-watch: " .. sig)
  end
end

function M.ensurePause()
  if C.PAUSE_BUTTON_ENABLED == false then return false end
  pcall(pauseWatch)
  -- The game builds a brand-new pause widget every time the menu opens and leaves the old ones lying
  -- around, so the live menu is always the newest one (last in the list).
  local all = FindAllOf(C.PAUSE_HOST_CLASS)
  local newest, nname
  if all then
    for i = #all, 1, -1 do
      if valid(all[i]) then
        newest = all[i]
        nname = objPath(newest)
        break
      end
    end
  end
  if S.pauseBtnPath then
    if resolve(S.pauseHostPath) and resolve(S.pauseBtnPath) and resolve(S.pauseRefPath)
       and (not nname or S.pauseHostPath == nname) then
      return mirrorPause()
    end
    -- a newer menu exists (or ours was destroyed): forget the old button without touching it
    if reopenLogs < 20 then reopenLogs = reopenLogs + 1; Log("pause: new menu instance; building the button there") end
    S.pauseBtnPath, S.pauseRefPath, S.pauseHostPath = nil, nil, nil
    S.pauseVis, S.pauseOp, S.pauseShown = nil, nil, false
    dropOwner("pause")
  end
  local hosts = newest and { newest } or nil
  if not hosts then return false end
  for _, host in ipairs(hosts) do
    local hname
    if valid(host) then pcall(function() hname = host:GetFullName() end) end
    if hname and not pauseTried[hname] and hostOk(host, C.PAUSE_HOST_CLASS) then
      -- a few tries per menu (its contents may not be built yet right after it is created)
      pauseTries = pauseTries or {}
      pauseTries[hname] = (pauseTries[hname] or 0) + 1
      if pauseTries[hname] >= 6 then pauseTried[hname] = true end
      S.pauseAttempts = (S.pauseAttempts or 0) + 1
      if S.pauseAttempts <= 25 then Log("pause: attempt " .. S.pauseAttempts .. " on " .. hname) end
      local root, kind = rootKind(host)
      once("p-host", "pause: found " .. className(host) .. ", root=" .. tostring(kind))
      if root then
        local texts = collectTexts(host, {}, 0)
        once("p-texts", "pause: found " .. #texts .. " text widgets")
        for _, tb in ipairs(texts) do
          if lowerText(tb) == C.PAUSE_ANCHOR_TEXT:lower() then
            local ref = menuOf(tb)
            once("p-ref", "pause: options button widget = " .. (valid(ref) and className(ref) or "NOT FOUND"))
            local container = valid(ref) and findContainer(root, ref, 0) or nil
            once("p-cont", "pause: container = " .. (valid(container) and className(container) or "NOT FOUND"))
            if valid(ref) and valid(container) then
              S.host, S.tree = host, host.WidgetTree
              harvestFont(tb)
              local mine = createGameButton(host, ref)
              if not mine then return false end
              if insertAfter(container, ref, mine) then
                S.pauseBtnPath, S.pauseRefPath, S.pauseHostPath = objPath(mine), objPath(ref), objPath(host)
                S.pauseVis, S.pauseOp = nil, nil
                local entry = clickable(nil, function()
                  local pc = M.pauseCtx()
                  if pc then useCtx(pc); if M.onMods then M.onMods() end end
                end, { R = 1, G = 1, B = 1, A = 1 }, "menu")
                local bpath = S.pauseBtnPath
                entry.resolve = function() return resolve(S.pauseBtnPath) end
                entry.owner = "pause"
                entry.notint = true
                if ExecuteWithDelay then
                  ExecuteWithDelay(300, function() ExecuteInGameThread(function() setLabel(resolve(bpath)) end) end)
                  ExecuteWithDelay(1500, function() ExecuteInGameThread(function() setLabel(resolve(bpath)) end) end)
                end
                Log("Added the mods button to the pause menu.")
                return true
              else
                pcall(function() mine:RemoveFromParent() end)
                if not pauseWarned then
                  pauseWarned = true
                  Log("Couldn't place the mods button under options in the pause menu.")
                end
                return false
              end
            end
          end
        end
      end
    end
  end
  return false
end

-- Debug: writes the widget tree of every on-screen user widget -----------------------
function M.dump(path)
  local out = {}
  local function clsName(w)
    local ok, n = pcall(function() return w:GetClass():GetFName():ToString() end)
    return ok and n or "?"
  end
  local function nameOf(w)
    local ok, n = pcall(function() return w:GetFName():ToString() end)
    return ok and n or "?"
  end
  local function walk(w, depth)
    if depth > 16 or not valid(w) then return end
    local ind = string.rep("  ", depth)
    local line = ind .. clsName(w) .. " '" .. nameOf(w) .. "'"
    if clsName(w):find("TextBlock") then line = line .. "  text=" .. tostring(lowerText(w)) end
    local okv, vis = pcall(function() return w:GetVisibility() end)
    if okv then line = line .. "  vis=" .. tostring(vis) end
    if isA(w, "/Script/UMG.Button") then
      pcall(function() line = line .. "  normal=" .. tostring(w.WidgetStyle.Normal.ResourceObject:GetFullName()) end)
    elseif isA(w, "/Script/UMG.Image") then
      pcall(function() line = line .. "  brush=" .. tostring(w.Brush.ResourceObject:GetFullName()) end)
    end
    out[#out + 1] = line
    local oku, tree = pcall(function() return w.WidgetTree end)
    if oku and valid(tree) then walk(tree.RootWidget, depth + 1) end
    local okc, n = pcall(function() return w:GetChildrenCount() end)
    if okc and n then
      for i = 0, n - 1 do
        local okx, ch = pcall(function() return w:GetChildAt(i) end)
        if okx then walk(ch, depth + 1) end
      end
    end
  end
  local all = FindAllOf("UserWidget") or {}
  for _, uw in ipairs(all) do
    local inView = false
    pcall(function() inView = uw:IsInViewport() end)
    if valid(uw) and inView then
      out[#out + 1] = "=== in viewport: " .. tostring(uw:GetFullName())
      walk(uw, 0)
      out[#out + 1] = ""
    end
  end
  local f = io.open(path, "w")
  if f then f:write(table.concat(out, "\n")); f:close() end
  Log("Wrote " .. path .. " (" .. #out .. " lines)")
end

function M.init(config, logger)
  C, Log = config, logger
end

return M

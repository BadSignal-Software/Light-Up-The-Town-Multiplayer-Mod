ModManager for Light Up The Town (UE4SS Lua mod)
================================================

INSTALL
  Copy this whole "ModManager" folder into  ...\Binaries\Win64\ue4ss\Mods\
  (same place as LUTTNet). enabled.txt is already inside. Start the game:
  a "mods" button appears bottom-left on the main menu. F8 also opens it.

WHAT IT SHOWS
  Every folder inside Mods\ that contains modmanager.json (or modmanager.txt).
  Click a mod in the left list to see its info and pictures on the right.
  Mouse wheel / Up / Down scroll. "back" or Esc closes it.

modmanager.json  (all fields optional; comments and trailing commas are allowed)
  {
    "name": "New Lights",
    "version": "1.0",
    "author": "You",
    "description": "One-line summary.",
    "long_description": "Longer text.\nNew lines work.",
    "website": "https://...",
    "tags": ["lights", "decor"],
    "dependencies": ["UE4SS"],
    "game_version": "1.1.1",
    "icon": "icon.png",
    "images": [
      { "file": "warm.png", "title": "Warm glow", "caption": "What it looks like" },
      "other.png"
    ],
    "anything_else": "Any other field is listed under 'info' automatically."
  }

modmanager.txt  (same idea, simpler)
  name: New Lights
  version: 1.0
  author: You
  description: One-line summary.
  tags: lights, decor
  long description:
    Indented lines continue the previous field.
  images: warm.png | Warm glow; other.png | Another caption
  Release Date: 2026-10-01        <- unknown keys show up under 'info'

IMAGES
  Put pictures in an "images" folder inside the mod's folder (png, jpg, bmp).
  Every picture there is shown, even if it isn't listed in the manifest.
  Title/caption come from, in order: the manifest entry, images\images.json
  (or metadata.json / captions.json: { "warm.png": { "title": "..", "caption": ".." } }),
  then the file name. The pixel size is read from the file itself and shown too.
  "icon" is shown at the top of the mod page instead of in the gallery.

PAUSE MENU
  A "mods" button is also added right under "options" in the pause menu (a copy of the game's own button).

FADING
  Like the game's own buttons, the "mods" button fades after a few idle seconds and returns when you move the mouse.
  Change IDLE_FADE_SECONDS in scripts\mm_config.lua (0 = never fade).

RELOAD
  The "reload" button re-reads every modmanager file and images folder, so edits show up without leaving the menu.

TURNING MODS ON/OFF
  Each mod page has a "turn off" / "turn on" button. It adds or removes the mod's enabled.txt
  (and flips its line in Mods\mods.txt if it has one). UE4SS only reads these at startup,
  so the change applies the next time the game starts. ModManager can't turn itself off.

SETTINGS  scripts\mm_config.lua  (button size/position, colours, key binds, ...)

IF SOMETHING LOOKS WRONG
  modmanager_log.txt (in this folder) says what happened.
  If there's no mods button, or it looks off: open the main menu, press F7, and send
  menu_dump.txt (also in this folder). It lists the menu's widgets so the hookup can be fixed.

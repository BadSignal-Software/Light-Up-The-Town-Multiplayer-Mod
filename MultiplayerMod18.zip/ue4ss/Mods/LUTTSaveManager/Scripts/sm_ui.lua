-- SaveManager UI: the slot picker and the yes/no overwrite prompt, built from plain UMG widgets
-- attached to the main menu's own widget tree (same technique as ModManager).
local M = {}

local Log = function() end
local S = {
  host = nil, tree = nil, attach = nil, kind = nil,
  panel = nil, confirm = nil, clicks = {},
  refFont = nil, onBack = nil, onConfirmNo = nil,
}

local PAL = {
  dim = "#0d0816", card = "#2b2340", text = "#f6f1e7", subtle = "#bdb4d3", dark = "#3a3358",
  purple = "#9992d1", lavender = "#d5d8f0", olive = "#c0bd8e", salmon = "#ce9e87",
  sage = "#a3c6a3", sand = "#d2c5b0", flame = "#ffd37a", disabled = "#4a4268",
}

-- helpers ------------------------------------------------------------------------
local function valid(o)
  if o == nil then return false end
  local ok, v = pcall(function() return o:IsValid() end)
  return ok and v == true
end

local function try(what, fn, ...)
  local ok, err = pcall(fn, ...)
  if not ok then Log("[" .. what .. "] " .. tostring(err)) end
  return ok, err
end

local function srgb(c)
  c = c / 255
  if c <= 0.04045 then return c / 12.92 end
  return ((c + 0.055) / 1.055) ^ 2.4
end
local function color(hex, a)
  local r, g, b = hex:match("#?(%x%x)(%x%x)(%x%x)")
  return { R = srgb(tonumber(r, 16)), G = srgb(tonumber(g, 16)), B = srgb(tonumber(b, 16)), A = a or 1 }
end
local function slate(hex, a) return { SpecifiedColor = color(hex, a), ColorUseRule = 0 } end
local function lighten(c, k) return { R = c.R + (1 - c.R) * k, G = c.G + (1 - c.G) * k, B = c.B + (1 - c.B) * k, A = c.A } end

local function new(className)
  local cls = StaticFindObject("/Script/UMG." .. className)
  return StaticConstructObject(cls, S.tree)
end

local HFILL, HLEFT, HCENTER, HRIGHT = 0, 1, 2, 3
local VFILL, VTOP, VCENTER, VBOTTOM = 0, 1, 2, 3

local function add(parent, child, o)
  local sl = parent:AddChild(child)
  if o and sl then
    if o.pad then try("pad", function() sl:SetPadding({ Left = o.pad[1], Top = o.pad[2], Right = o.pad[3], Bottom = o.pad[4] }) end) end
    if o.fill then try("fill", function() sl:SetSize({ Value = o.fill, SizeRule = 1 }) end) end
    if o.h then try("h", function() sl:SetHorizontalAlignment(o.h) end) end
    if o.v then try("v", function() sl:SetVerticalAlignment(o.v) end) end
  end
  return sl
end

local function font(t, size)
  try("font", function()
    local f = t.Font
    if S.refFont then
      if S.refFont.obj then f.FontObject = S.refFont.obj end
      if S.refFont.face then f.TypefaceFontName = S.refFont.face end
    end
    f.Size = size
  end)
end

local function text(str, size, hex, o)
  o = o or {}
  local t = new("TextBlock")
  font(t, size)
  try("text", function() t:SetText(FText(str or "")) end)
  try("textcolor", function() t:SetColorAndOpacity(slate(hex or PAL.text)) end)
  if o.wrap then try("wrap", function() t:SetAutoWrapText(true) end) end
  if o.center then try("just", function() t:SetJustification(1) end) end
  return t
end

local function roundBorder(kind)
  local b = new("Border")
  try("roundbox", function()
    local bg = b.Background
    bg.DrawAs = 4
    if kind == "pill" then
      bg.OutlineSettings.RoundingType = 1
    else
      bg.OutlineSettings.RoundingType = 0
      bg.OutlineSettings.CornerRadii = { X = kind, Y = kind, Z = kind, W = kind }
    end
    bg.TintColor = slate("#ffffff")
  end)
  return b
end

local function framed(kind, fillHex, alpha, outlineHex, outlinePx)
  local outer = roundBorder(kind)
  local inner = roundBorder(kind == "pill" and "pill" or math.max(kind - (outlinePx or 5), 4))
  try("outer", function() outer:SetBrushColor(color(outlineHex or "#ffffff")) end)
  try("innercol", function() inner:SetBrushColor(color(fillHex, alpha)) end)
  local px = outlinePx or 5
  try("outerpad", function() outer:SetPadding({ Left = px, Top = px, Right = px, Bottom = px }) end)
  try("outerchild", function() outer:SetContent(inner) end)
  return outer, inner
end

local function sized(child, w, h)
  local sb = new("SizeBox")
  if w then try("w", function() sb:SetWidthOverride(w) end) end
  if h then try("h", function() sb:SetHeightOverride(h) end) end
  try("sbc", function() sb:SetContent(child) end)
  return sb
end

-- clicks -------------------------------------------------------------------------
-- Everything clickable is handled by one global left-click key bind + IsHovered().
local function clickable(w, fn, baseColor, group, notint)
  local e = {
    w = w, fn = fn, base = baseColor, hov = baseColor and lighten(baseColor, 0.22) or nil,
    hovered = false, group = group, notint = notint or baseColor == nil,
  }
  S.clicks[#S.clicks + 1] = e
  return e
end

local function dropClicks(group)
  local keep = {}
  for _, e in ipairs(S.clicks) do if e.group ~= group then keep[#keep + 1] = e end end
  S.clicks = keep
end

local function isActive(e)
  if valid(S.confirm) then return e.group == "confirm" end
  if valid(S.panel) then return e.group == "panel" end
  return e.group == "menu"
end

function M.hoverTick()
  for _, e in ipairs(S.clicks) do
    if isActive(e) and valid(e.w) and not e.notint then
      local ok, h = pcall(function() return e.w:IsHovered() end)
      h = ok and h == true
      if h ~= e.hovered then
        e.hovered = h
        try("hover", function() e.w:SetBrushColor(h and e.hov or e.base) end)
      end
    end
  end
end

local lastClick = -10
function M.click()
  local now = os.clock()
  if now - lastClick < 0.18 then return end
  for i = #S.clicks, 1, -1 do
    local e = S.clicks[i]
    if isActive(e) and valid(e.w) then
      local ok, h = pcall(function() return e.w:IsHovered() end)
      if ok and h == true then
        lastClick = now
        try("click", e.fn)
        return
      end
    end
  end
end

-- the game's own New Game / Continue buttons: list = { { w = widget, fn = function } }
function M.setMenuButtons(list)
  dropClicks("menu")
  for _, b in ipairs(list) do
    if valid(b.w) then clickable(b.w, b.fn, nil, "menu", true) end
  end
end

-- attaching ----------------------------------------------------------------------
local function lowerText(tb)
  local ok, s = pcall(function() return tb:GetText():ToString() end)
  if ok and type(s) == "string" then return (s:gsub("^%s+", ""):gsub("%s+$", "")):lower() end
end

local function isA(o, path)
  local ok, r = pcall(function() return o:IsA(StaticFindObject(path)) end)
  return ok and r == true
end

function M.bindHost(host)
  if not valid(host) then return false end
  local ok, tree = pcall(function() return host.WidgetTree end)
  if not ok or not valid(tree) then return false end
  local okr, root = pcall(function() return tree.RootWidget end)
  if not okr or not valid(root) then return false end
  local kind
  if isA(root, "/Script/UMG.CanvasPanel") then kind = "canvas"
  elseif isA(root, "/Script/UMG.Overlay") then kind = "overlay" end
  if not kind then return false end
  S.host, S.tree, S.attach, S.kind = host, tree, root, kind

  -- borrow the menu's font from its "new game" label
  S.refFont = nil
  for _, cn in ipairs({ "CommonTextBlock", "TextBlock" }) do
    local list = FindAllOf(cn)
    if list then
      for _, tb in ipairs(list) do
        if valid(tb) and lowerText(tb) == "new game" then
          try("refFont", function()
            local f = tb.Font
            S.refFont = { obj = f.FontObject, face = f.TypefaceFontName }
          end)
          if S.refFont then break end
        end
      end
    end
    if S.refFont then break end
  end
  return true
end

local function attachFull(widget, z)
  local sl = S.attach:AddChild(widget)
  if S.kind == "canvas" then
    try("anch", function() sl:SetAnchors({ Minimum = { X = 0, Y = 0 }, Maximum = { X = 1, Y = 1 } }) end)
    try("off", function() sl:SetOffsets({ Left = 0, Top = 0, Right = 0, Bottom = 0 }) end)
    try("z", function() sl:SetZOrder(z) end)
  else
    try("ha", function() sl:SetHorizontalAlignment(HFILL); sl:SetVerticalAlignment(VFILL) end)
  end
  return sl
end

-- close ---------------------------------------------------------------------------
function M.closeConfirm()
  if valid(S.confirm) then try("rm", function() S.confirm:RemoveFromParent() end) end
  S.confirm = nil
  dropClicks("confirm")
end

function M.closeAll()
  M.closeConfirm()
  if valid(S.panel) then try("rm", function() S.panel:RemoveFromParent() end) end
  S.panel = nil
  S.onBack = nil
  S.onConfirmNo = nil
  dropClicks("panel")
end

function M.isOpen() return valid(S.panel) or valid(S.confirm) end

-- Back / Escape: closes the prompt first, then the picker (calling onBack).
function M.back()
  if valid(S.confirm) then
    local no = S.onConfirmNo
    M.closeConfirm()
    if no then pcall(no) end
    return true
  end
  if valid(S.panel) then
    local cb = S.onBack
    M.closeAll()
    if cb then pcall(cb) end
    return true
  end
  return false
end

-- slot picker ---------------------------------------------------------------------
-- opts = { title=, subtitle=, onBack=,
--          slots = { { label=, sub=, exists=, location=, timeText=, active=, enabled=, hint=, onPick= } } }
local pastel = { "purple", "salmon", "sage" }

function M.openSlots(opts)
  if not valid(S.host) or not S.attach then return false end
  M.closeAll()
  S.onBack = opts.onBack
  dropClicks("panel")

  local dim = new("Border")
  try("dim", function() dim:SetBrushColor(color(PAL.dim, 0.78)) end)
  try("dimv", function() dim:SetVisibility(0) end)

  local cardOuter, card = framed(36, PAL.card, 0.97, "#ffffff", 6)
  try("cardpad", function() card:SetPadding({ Left = 44, Top = 30, Right = 44, Bottom = 40 }) end)
  local root = new("VerticalBox")

  local head = new("HorizontalBox")
  add(head, text(opts.title, 76, PAL.text), { fill = 1, v = VCENTER })
  local bo, bi = framed("pill", PAL.salmon, 1, "#ffffff", 5)
  try("bp", function() bi:SetPadding({ Left = 40, Top = 8, Right = 40, Bottom = 12 }) end)
  try("bc", function() bi:SetContent(text("back", 36, PAL.dark)) end)
  add(head, bo, { v = VCENTER })
  clickable(bi, function() M.back() end, color(PAL.salmon), "panel")
  add(root, head, { pad = { 0, 0, 0, 8 } })
  add(root, text(opts.subtitle or "", 28, PAL.subtle), { pad = { 0, 0, 0, 26 } })

  local body = new("HorizontalBox")
  for i, s in ipairs(opts.slots) do
    local fill = s.enabled and PAL[pastel[(i - 1) % #pastel + 1]] or PAL.disabled
    local textHex = s.enabled and PAL.dark or PAL.subtle
    local outer, inner = framed(30, fill, 1, s.active and PAL.flame or "#ffffff", s.active and 8 or 5)
    try("ip", function() inner:SetPadding({ Left = 30, Top = 24, Right = 30, Bottom = 26 }) end)

    local col = new("VerticalBox")
    add(col, text(s.label, 56, textHex), { pad = { 0, 0, 0, 2 } })
    add(col, text(s.sub or " ", 26, textHex), { pad = { 0, 0, 0, 36 } })
    if s.exists then
      add(col, text(s.location or "unknown level", 42, textHex, { wrap = true }), { pad = { 0, 0, 0, 10 } })
      add(col, text(s.timeText or "", 30, textHex, { wrap = true }), { pad = { 0, 0, 0, 10 } })
    else
      add(col, text("empty", 42, textHex), { pad = { 0, 0, 0, 10 } })
    end
    if s.hint then add(col, text(s.hint, 26, textHex, { wrap = true })) end
    if s.active then add(col, text("current save", 26, textHex), { pad = { 0, 14, 0, 0 } }) end
    try("ic", function() inner:SetContent(sized(col, nil, 400)) end)

    add(body, outer, { fill = 1, pad = { i == 1 and 0 or 12, 0, i == #opts.slots and 0 or 12, 0 } })
    if s.enabled then
      clickable(inner, function() if s.onPick then s.onPick() end end, color(fill), "panel")
    end
  end
  add(root, body)

  try("cr", function() card:SetContent(root) end)
  try("dimc", function() dim:SetContent(sized(cardOuter, 1560, 700)) end)
  try("dimh", function() dim:SetHorizontalAlignment(HCENTER); dim:SetVerticalAlignment(VCENTER) end)

  S.panel = dim
  attachFull(dim, 5000)
  return true
end

-- yes / no prompt -------------------------------------------------------------------
-- opts = { message=, yes=, no=, onYes=, onNo= }
function M.openConfirm(opts)
  if not valid(S.host) or not S.attach then return false end
  M.closeConfirm()
  S.onConfirmNo = opts.onNo

  local dim = new("Border")
  try("dim", function() dim:SetBrushColor(color(PAL.dim, 0.7)) end)
  try("dimv", function() dim:SetVisibility(0) end)

  local cardOuter, card = framed(36, PAL.card, 1, "#ffffff", 6)
  try("cardpad", function() card:SetPadding({ Left = 56, Top = 44, Right = 56, Bottom = 48 }) end)
  local col = new("VerticalBox")
  add(col, text(opts.message, 40, PAL.text, { wrap = true, center = true }), { pad = { 0, 0, 0, 40 }, h = HCENTER })

  local row = new("HorizontalBox")
  local yo, yi = framed("pill", PAL.salmon, 1, "#ffffff", 5)
  try("yp", function() yi:SetPadding({ Left = 80, Top = 8, Right = 80, Bottom = 14 }) end)
  try("yc", function() yi:SetContent(text(opts.yes or "yes", 46, PAL.dark)) end)
  add(row, yo, { pad = { 0, 0, 36, 0 } })
  clickable(yi, function()
    M.closeConfirm()
    if opts.onYes then opts.onYes() end
  end, color(PAL.salmon), "confirm")

  local no, ni = framed("pill", PAL.sage, 1, "#ffffff", 5)
  try("np", function() ni:SetPadding({ Left = 80, Top = 8, Right = 80, Bottom = 14 }) end)
  try("nc", function() ni:SetContent(text(opts.no or "no", 46, PAL.dark)) end)
  add(row, no)
  clickable(ni, function()
    local cb = opts.onNo
    M.closeConfirm()
    if cb then cb() end
  end, color(PAL.sage), "confirm")
  add(col, row, { h = HCENTER })

  try("cr", function() card:SetContent(col) end)
  try("dimc", function() dim:SetContent(sized(cardOuter, 1040, 440)) end)
  try("dimh", function() dim:SetHorizontalAlignment(HCENTER); dim:SetVerticalAlignment(VCENTER) end)

  S.confirm = dim
  attachFull(dim, 5100)
  return true
end

function M.init(logger)
  if logger then Log = logger end
end

return M

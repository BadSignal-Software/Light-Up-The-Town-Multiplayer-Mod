-- SaveManager for Light Up The Town (UE4SS Lua mod)
--
-- Three save slots. The game only knows one set of files (user_0.sav, MasterSaveData.sav and one
-- file per level) in %LOCALAPPDATA%\LightUpTheTown\Saved\SaveGames. Each slot keeps its own copy of
-- that set in SaveGames\LUTTSlots\slotN; picking a slot swaps its files in. Every time the game
-- saves, the saved file is copied into the slot you are playing, so "save and quit" always lands in
-- the right slot.
local Ui = require("sm_ui")

local SRC = debug.getinfo(1, "S").source
local srcPath = SRC:gsub("^@", ""):gsub("\\", "/")
local MOD_DIR = srcPath:match("^(.*)/[^/]+/[^/]+$")

local logStarted = false
local function Log(msg)
  print("[SaveManager] " .. tostring(msg) .. "\n")
  if MOD_DIR then
    local f = io.open(MOD_DIR .. "/savemanager_log.txt", logStarted and "a" or "w")
    if f then logStarted = true; f:write(os.date("%H:%M:%S ") .. tostring(msg) .. "\n"); f:close() end
  end
end

Ui.init(Log)

-- Settings -------------------------------------------------------------------------------
local SLOT_COUNT = 3
local MENU_CLASS = "W_MainMenu_C"
local MENU_PATH = "/Game/UserInterface/W_MainMenu.W_MainMenu_C:"
local GI_PATH = "/Game/Blueprints/DecorationList/GameInstance_LUTT.GameInstance_LUTT_C:"
local NEW_HANDLER = "BndEvt__W_MainMenu_button_new_K2Node_ComponentBoundEvent_4_CommonButtonBaseClicked__DelegateSignature"
local CONT_HANDLER = "BndEvt__W_MainMenu_UI_LUTT_Button_Generic_3_K2Node_ComponentBoundEvent_2_CommonButtonBaseClicked__DelegateSignature"
local MASTER_SLOT = "MasterSaveData"

local localAppData = os.getenv("LOCALAPPDATA")
if not localAppData or localAppData == "" then
  localAppData = (os.getenv("USERPROFILE") or "C:\\Users\\Public") .. "\\AppData\\Local"
end
local SAVE_DIR = localAppData .. "\\LightUpTheTown\\Saved\\SaveGames"
local ROOT = SAVE_DIR .. "\\LUTTSlots"
local STATE_FILE = ROOT .. "\\slots.txt"
local BACKUP_DIR = ROOT .. "\\original_backup"

local State = {
  active = nil,            -- slot number whose files are currently in SaveGames
  slots = {},              -- [n] = { seconds = 0, location = nil }
  playing = false,         -- true between picking a slot and returning to the main menu
  passing = false,         -- true while we call the game's own click handler
  dirty = false,
  hostName = nil,
  ticks = 0,
  userFile = "user_0",
}
for i = 1, SLOT_COUNT do State.slots[i] = { seconds = 0, location = nil } end

-- small helpers -------------------------------------------------------------------------
local function valid(o)
  if o == nil then return false end
  local ok, v = pcall(function() return o:IsValid() end)
  return ok and v == true
end

local function toStr(v)
  if type(v) == "string" then return v end
  if v == nil then return nil end
  local ok, s = pcall(function() return v:ToString() end)
  if ok and s then return s end
  return tostring(v)
end

local function paramStr(p)
  local ok, v = pcall(function() return p:get() end)
  if not ok then v = p end
  return toStr(v)
end

-- Post-hooks pass the parameters in a different position than pre-hooks, so look through all of
-- them for the one that is text (the slot name) instead of trusting a fixed position.
local function firstString(...)
  for _, p in ipairs({ ... }) do
    local ok, v = pcall(function() return p:get() end)
    if not ok then v = p end
    if type(v) == "string" then return v end
    if type(v) == "userdata" then
      local ok2, str = pcall(function() return v:ToString() end)
      if ok2 and type(str) == "string" and str ~= "" and not str:find("^UObject") then return str end
    end
  end
end

local function slotDir(i) return ROOT .. "\\slot" .. i end

local function readFile(path)
  local f = io.open(path, "rb")
  if not f then return nil end
  local s = f:read("a")
  f:close()
  return s
end

local function writeFile(path, data)
  local f = io.open(path, "wb")
  if not f then return false end
  f:write(data)
  f:close()
  return true
end

local function fileExists(path)
  local f = io.open(path, "rb")
  if f then f:close(); return true end
  return false
end

local function copyFile(src, dst)
  local d = readFile(src)
  if not d then return false end
  return writeFile(dst, d)
end

local function run(cmd)
  local p = io.popen(cmd)
  if not p then return "" end
  local out = p:read("a") or ""
  p:close()
  return out
end

local function listSav(dir)
  local out = {}
  local text = run('cmd /c dir /b "' .. dir .. '\\*.sav" 2>nul')
  for line in text:gmatch("[^\r\n]+") do
    if line:lower():match("%.sav$") then out[#out + 1] = line end
  end
  return out
end

local function listSavNewest(dir)
  local out = {}
  local text = run('cmd /c dir /b /o-d "' .. dir .. '\\*.sav" 2>nul')
  for line in text:gmatch("[^\r\n]+") do
    if line:lower():match("%.sav$") then out[#out + 1] = line end
  end
  return out
end

local function mkdirs(list)
  local parts = {}
  for _, d in ipairs(list) do parts[#parts + 1] = 'if not exist "' .. d .. '" mkdir "' .. d .. '"' end
  run('cmd /c ' .. table.concat(parts, " & ") .. ' 2>nul')
end

-- Reads CurrentLocation out of a Save_User .sav (GVAS: name, "StrProperty", size, flag, value).
local function parseLocation(data)
  if not data then return nil end
  local ok, res = pcall(function()
    local p = data:find("CurrentLocation\0", 1, true)
    if not p then return nil end
    local t = "StrProperty\0"
    local q = data:find(t, p, true)
    if not q then return nil end
    q = q + #t + 9                              -- 8 byte size + 1 byte guid flag
    local len = string.unpack("<i4", data, q)
    q = q + 4
    if len > 1 and len < 200 then
      return data:sub(q, q + len - 2)
    elseif len < -1 and len > -200 then
      local n = -len
      local chars = {}
      for i = 0, n - 2 do chars[#chars + 1] = string.char(data:byte(q + i * 2)) end
      return table.concat(chars)
    end
  end)
  if ok and type(res) == "string" and res ~= "" then return res end
end

local function fmtTime(sec)
  sec = math.floor(sec or 0)
  if sec <= 0 then return "time played: not tracked yet" end
  local h = sec // 3600
  local m = (sec % 3600) // 60
  if h > 0 then return string.format("%dh %dm played", h, m) end
  if m > 0 then return string.format("%dm played", m) end
  return "under a minute played"
end

local function prettyLocation(loc)
  if not loc or loc == "" then return "unknown level" end
  return (loc:gsub("_", " "))
end

-- "Midtown01_0.sav" -> "Midtown", "Suburb01Edit_0.sav" -> "Suburb", "Tutorial_Home_1.sav" -> "Tutorial Home"
local function levelFromFile(file)
  local n = file:gsub("%.[Ss][Aa][Vv]$", "")
  n = n:gsub("_%d+$", ""):gsub("Edit$", ""):gsub("%d+$", ""):gsub("_+$", "")
  if n == "" then return nil end
  return (n:gsub("_", " "))
end

local function isLevelFile(file)
  local n = file:gsub("%.[Ss][Aa][Vv]$", "")
  return n ~= MASTER_SLOT and not n:lower():match("^user_")
end

-- the level you last saved in = the newest level file in the live save folder
local function levelFromLive()
  for _, name in ipairs(listSavNewest(SAVE_DIR)) do
    if isLevelFile(name) then return levelFromFile(name) end
  end
end

-- state file -----------------------------------------------------------------------------
local function saveState()
  local lines = { "active=" .. tostring(State.active or "") }
  for i = 1, SLOT_COUNT do
    lines[#lines + 1] = string.format("slot%d.seconds=%d", i, math.floor(State.slots[i].seconds))
    lines[#lines + 1] = string.format("slot%d.location=%s", i, State.slots[i].location or "")
    lines[#lines + 1] = string.format("slot%d.level=%s", i, State.slots[i].level or "")
  end
  writeFile(STATE_FILE, table.concat(lines, "\n") .. "\n")
  State.dirty = false
end

local function loadState()
  local text = readFile(STATE_FILE)
  if not text then return false end
  for line in text:gmatch("[^\r\n]+") do
    local k, v = line:match("^([%w%.]+)=(.*)$")
    if k == "active" then
      State.active = tonumber(v)
    elseif k then
      local n, field = k:match("^slot(%d+)%.(%w+)$")
      n = tonumber(n)
      if n and State.slots[n] then
        if field == "seconds" then State.slots[n].seconds = tonumber(v) or 0
        elseif field == "location" then State.slots[n].location = (v ~= "" and v or nil)
        elseif field == "level" then State.slots[n].level = (v ~= "" and v or nil) end
      end
    end
  end
  return State.active ~= nil
end

-- slot file operations --------------------------------------------------------------------
local function livePath(name) return SAVE_DIR .. "\\" .. name end

local function refreshLocation(i)
  local data = readFile(slotDir(i) .. "\\" .. State.userFile .. ".sav")
  local loc = parseLocation(data)
  if loc then State.slots[i].location = loc end
end

local function slotHasSave(i)
  return fileExists(slotDir(i) .. "\\" .. State.userFile .. ".sav")
end

-- copy every live save into the slot being played
local function syncAll()
  if not State.active then return end
  local n = 0
  for _, name in ipairs(listSav(SAVE_DIR)) do
    if copyFile(livePath(name), slotDir(State.active) .. "\\" .. name) then n = n + 1 end
  end
  refreshLocation(State.active)
  State.dirty = true
  Log("Copied " .. n .. " live save file(s) into slot " .. State.active)
end

local function clearLive()
  for _, name in ipairs(listSav(SAVE_DIR)) do os.remove(livePath(name)) end
end

local function clearSlot(i)
  for _, name in ipairs(listSav(slotDir(i))) do os.remove(slotDir(i) .. "\\" .. name) end
end

local function loadSlotIntoLive(i)
  local n = 0
  for _, name in ipairs(listSav(slotDir(i))) do
    if copyFile(slotDir(i) .. "\\" .. name, livePath(name)) then n = n + 1 end
  end
  Log("Loaded " .. n .. " file(s) from slot " .. i .. " into the live save folder")
end

-- the game keeps its saves in memory; after swapping files, reload them
local function reloadMemory()
  local gi = FindFirstOf("GameInstance_LUTT_C")
  if not valid(gi) then Log("reloadMemory: no GameInstance_LUTT_C found"); return end
  local statics = StaticFindObject("/Script/Engine.Default__GameplayStatics")
  local uid = toStr(gi.CurrentUserID) or State.userFile
  local ok, err = pcall(function()
    local u = statics:LoadGameFromSlot(uid, 0)
    if valid(u) then gi.CurrentUserSave = u; Log("Reloaded user save '" .. uid .. "' into memory")
    else Log("reloadMemory: LoadGameFromSlot(" .. uid .. ") gave nothing") end
    local m = statics:LoadGameFromSlot(MASTER_SLOT, 0)
    if valid(m) then gi.MasterSaveGameData = m; Log("Reloaded master save into memory")
    else Log("reloadMemory: no master save found") end
  end)
  if not ok then Log("reloadMemory failed: " .. tostring(err)) end
end

-- first run: copy whatever is in the game's folder into slot 1 (plus a one-time untouched backup)
local function init()
  mkdirs({ ROOT, BACKUP_DIR, slotDir(1), slotDir(2), slotDir(3) })
  if loadState() then
    Log("Loaded slot info. Active slot: " .. tostring(State.active))
    if State.active == 1 and not State.slots[1].level then
      State.slots[1].level = levelFromLive()
      saveState()
    end
    return
  end
  local files = listSav(SAVE_DIR)
  for _, name in ipairs(files) do
    copyFile(livePath(name), BACKUP_DIR .. "\\" .. name)
    copyFile(livePath(name), slotDir(1) .. "\\" .. name)
  end
  State.active = 1
  refreshLocation(1)
  State.slots[1].level = levelFromLive()
  saveState()
  Log("First run: copied " .. #files .. " save file(s) into slot 1 and into original_backup")
end

-- game hooks ----------------------------------------------------------------------------
local hooked, hookWarned = {}, {}
local function hook(id, path, pre, post)
  if hooked[id] then return end
  local ok, err
  if post then ok, err = pcall(RegisterHook, path, pre or function() end, post)
  else ok, err = pcall(RegisterHook, path, pre) end
  if ok then
    hooked[id] = true
    Log("Hooked " .. id)
  elseif not hookWarned[id] then
    hookWarned[id] = true
    Log("Couldn't hook " .. id .. " yet: " .. tostring(err))
  end
end

local function onGameSaved(name)
  Log("game saved '" .. tostring(name) .. "' (active slot " .. tostring(State.active) .. ")")
  if not State.active or not name or name == "" then return end
  local file = name .. ".sav"
  if copyFile(livePath(file), slotDir(State.active) .. "\\" .. file) then
    if name == State.userFile then
      refreshLocation(State.active)
    elseif isLevelFile(file) then
      State.slots[State.active].level = levelFromFile(file)
    end
    State.dirty = true
  end
end

local function ensureHooks()
  hook("SaveGameToSlot", "/Script/Engine.GameplayStatics:SaveGameToSlot", nil, function(self, ...)
    local ok, err = pcall(onGameSaved, firstString(...))
    if not ok then Log("onGameSaved: " .. tostring(err)) end
  end)
  hook("DeleteGameInSlot", "/Script/Engine.GameplayStatics:DeleteGameInSlot", nil, function(self, ...)
    local name = firstString(...)
    if State.active and name and name ~= "" then os.remove(slotDir(State.active) .. "\\" .. name .. ".sav") end
  end)
  hook("QuitGameMaster", GI_PATH .. "QuitGameMaster", function()
    pcall(syncAll)
    pcall(saveState)
  end)
  hook("ClearCampaignData", GI_PATH .. "ClearCampaignData", function() Log("game: ClearCampaignData") end)
  hook("ResetCurrentUserData", GI_PATH .. "ResetCurrentUserData", function() Log("game: ResetCurrentUserData") end)
  hook("NewGameHandler", MENU_PATH .. NEW_HANDLER, function()
    if not State.passing then Log("the game's own New Game handler fired") end
  end)
  hook("ContinueHandler", MENU_PATH .. CONT_HANDLER, function()
    if not State.passing then Log("the game's own Continue handler fired") end
  end)
end

-- calling the game's own handlers -----------------------------------------------------------
local function callNewGame()
  local menu = FindFirstOf(MENU_CLASS)
  if not valid(menu) then Log("callNewGame: main menu not found"); return end
  State.passing = true
  local ok, err = pcall(function() menu:NewGamePromptAnswered(true) end)
  State.passing = false
  if ok then Log("Called the game's NewGamePromptAnswered(true)")
  else Log("NewGamePromptAnswered failed: " .. tostring(err)) end
end

local function callContinue()
  local menu = FindFirstOf(MENU_CLASS)
  if not valid(menu) then Log("callContinue: main menu not found"); return end
  State.passing = true
  local ok, err = pcall(function() menu[CONT_HANDLER](menu, menu.button_continue) end)
  State.passing = false
  if ok then Log("Called the game's Continue handler")
  else Log("Continue handler failed: " .. tostring(err)) end
end

-- flows ---------------------------------------------------------------------------------
local function startContinue(n)
  Ui.closeAll()
  local ok, err = pcall(function()
    if State.active ~= n then
      syncAll()
      clearLive()
      loadSlotIntoLive(n)
      State.active = n
      saveState()
      reloadMemory()
    end
    State.playing = true
    State.graceUntil = os.time() + 25
    callContinue()
  end)
  if not ok then Log("Continue on slot " .. n .. " failed: " .. tostring(err)) end
end

local function startNewGame(n)
  Ui.closeAll()
  local ok, err = pcall(function()
    syncAll()
    clearLive()
    clearSlot(n)
    State.active = n
    State.slots[n].seconds = 0
    State.slots[n].location = nil
    State.slots[n].level = nil
    saveState()
    State.playing = true
    State.graceUntil = os.time() + 25
    callNewGame()
  end)
  if not ok then Log("New game on slot " .. n .. " failed: " .. tostring(err)) end
end

local function slotInfo(i, mode)
  refreshLocation(i)
  local exists = slotHasSave(i)
  local info = {
    label = "slot " .. i,
    sub = (i == 1) and "main save" or " ",
    exists = exists,
    location = prettyLocation(State.slots[i].level or State.slots[i].location),
    timeText = fmtTime(State.slots[i].seconds),
    active = (State.active == i),
    enabled = (mode == "new") or exists,
  }
  if mode == "new" then
    info.hint = exists and "starting here overwrites this save" or "start a fresh game here"
  elseif not exists then
    info.hint = "nothing saved here yet"
  end
  return info
end

local openPicker
function openPicker(mode)
  local slots = {}
  for i = 1, SLOT_COUNT do
    local s = slotInfo(i, mode)
    s.onPick = function()
      Log("Picked slot " .. i .. " (" .. mode .. ", " .. (s.exists and "has a save" or "empty") .. ")")
      if mode == "continue" then
        startContinue(i)
      elseif s.exists then
        Ui.openConfirm({
          message = "Slot " .. i .. " already has a save (" .. s.location .. ", " .. s.timeText .. ").\nOverwrite it with a new game?",
          yes = "yes", no = "no",
          onYes = function() Log("Overwrite slot " .. i .. ": yes"); startNewGame(i) end,
          onNo = function() Log("Overwrite slot " .. i .. ": no") end,
        })
      else
        startNewGame(i)
      end
    end
    slots[#slots + 1] = s
  end
  local opened = Ui.openSlots({
    title = (mode == "new") and "new game" or "continue",
    subtitle = (mode == "new") and "choose a save slot to start in" or "choose a save slot to continue",
    slots = slots,
  })
  Log("Slot picker (" .. mode .. ") " .. (opened and "opened" or "FAILED to open"))
end

-- main menu hookup -----------------------------------------------------------------------
-- Testing switch: true = switch off the game's own New Game / Continue buttons (needed in the end,
-- but the first attempt broke the whole menu, so it is off while we work out why).
local BLOCK_ORIGINALS = false

-- The game's own buttons stay enabled (so hover, Settings, Quit etc. behave normally). When one of the
-- two we take over is pressed, switch it off for a moment so the game ignores that click, then restore it.
local pendingRelease = {}
local function guard(btn, label)
  if not valid(btn) then return end
  local ok = pcall(function() btn:SetIsInteractionEnabled(false) end)
  Log("Clicked " .. label .. " (guard " .. (ok and "on" or "FAILED") .. ")")
  pendingRelease[#pendingRelease + 1] = { btn = btn, at = os.clock() + 0.6 }
end

local function releaseGuards()
  if #pendingRelease == 0 then return end
  local keep = {}
  for _, g in ipairs(pendingRelease) do
    if valid(g.btn) then
      if os.clock() >= g.at then pcall(function() g.btn:SetIsInteractionEnabled(true) end)
      else keep[#keep + 1] = g end
    end
  end
  pendingRelease = keep
end

-- The menu lives in the game's menu stack (not directly in the viewport), so judge it by its visibility.
local function menuShown(menu)
  local ok, vis = pcall(function() return menu:GetVisibility() end)
  if not ok then return true end
  return vis == 0 or vis == 3 or vis == 4
end

local bindWarned = false

-- returns true while the main menu is on screen
local function ensureMenu()
  local menu = FindFirstOf(MENU_CLASS)
  if not valid(menu) or not menuShown(menu) then
    if State.onMenu ~= false then
      State.onMenu = false
      Log("Main menu is not on screen (" .. (valid(menu) and "hidden" or "not found") .. ")")
    end
    return false
  end
  if State.onMenu ~= true then
    State.onMenu = true
    Log("Main menu is on screen")
  end

  local name = menu:GetFullName()
  if State.hostName ~= name then
    if Ui.bindHost(menu) then
      State.hostName = name
      Ui.closeAll()
      Ui.setMenuButtons({
        { w = menu.button_new, fn = function() guard(menu.button_new, "New Game"); openPicker("new") end },
        { w = menu.button_continue, fn = function() guard(menu.button_continue, "Continue"); openPicker("continue") end },
      })
      Log("Attached to the main menu (" .. name .. ")")
    elseif not bindWarned then
      bindWarned = true
      Log("Couldn't attach to the main menu widget yet (" .. name .. ")")
    end
  end
  return true
end

-- poll: hooks, menu hookup, play time, state saving
LoopAsync(1000, function()
  ExecuteInGameThread(function()
    local ok, err = pcall(function()
      ensureHooks()
      local onMenu = ensureMenu()
      local grace = os.time() < (State.graceUntil or 0)   -- the menu fades out for a few seconds after you pick a slot
      if onMenu and not grace and State.playing then
        State.playing = false
        Log("Back at the main menu - copying the live save into slot " .. tostring(State.active))
        syncAll()
      end
      if State.playing and State.active and (grace or not onMenu) then
        State.slots[State.active].seconds = State.slots[State.active].seconds + 1
        State.dirty = true
      end
      State.ticks = State.ticks + 1
      if State.dirty and State.ticks % 20 == 0 then saveState() end
    end)
    if not ok then Log("poll: " .. tostring(err)) end
  end)
  return false
end)

LoopAsync(60, function()
  ExecuteInGameThread(function() pcall(Ui.hoverTick); pcall(releaseGuards) end)
  return false
end)

local function key(name, fallback) return (Key and Key[name]) or fallback end

RegisterKeyBind(key("LEFT_MOUSE_BUTTON", 0x01), function()
  ExecuteInGameThread(function() pcall(Ui.click) end)
end)
RegisterKeyBind(key("ESCAPE", 0x1B), function()
  ExecuteInGameThread(function() if Ui.isOpen() then Ui.back() end end)
end)

-- startup ---------------------------------------------------------------------------------
local okInit, errInit = pcall(init)
if not okInit then Log("init failed: " .. tostring(errInit)) end
Log("Loaded. Save folder: " .. SAVE_DIR)

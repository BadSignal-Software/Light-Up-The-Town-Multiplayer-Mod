-- MultiplayerMod for Light Up the Town
print("[MultiplayerMod] Initializing UE4SS Multiplayer Mod...\n")

-- Register Keybinds:
-- Press F5 to HOST a session
-- Press F6 to JOIN a host (127.0.0.1 by default)

local UEHelpers = require("UEHelpers")

RegisterKeyBind(Key.F6, function()
    print("[MultiplayerMod] Connecting to Host via Tailscale...\n")
    
    ExecuteInGameThread(function()
        local PC = UEHelpers.GetPlayerController()
        if PC and PC:IsValid() then
            -- Connects to your Tailscale IP address
            PC:ConsoleCommand("open 100.77.55.77", true)
        else
            print("[MultiplayerMod] Error: Player Controller not found.")
        end
    end)
end)

print("[MultiplayerMod] Loaded! Press F5 to Host, F6 to Join.\n")